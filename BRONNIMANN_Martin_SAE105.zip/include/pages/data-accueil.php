<?php

// Vidéos affichées sur la page d'accueil (Transmise à la vue Twig)
$videos = [
    [
        'id' => 'SM0B-s2ggzQ',
        'titre' => 'Sharks: Haxo'
    ],
    [
        'id' => 'RXerRpYcwuw',
        'titre' => 'Ace Aura: UMBRA'
    ],
    [
        'id' => 'XUlJN59Ivnc',
        'titre' => 'Skybreak: Soul Shards'
    ]
];